<?php

return [
    'masterdata' => [
        'name' => 'Master Data',
        'menus' => [
            ['id' => 'dashboard', 'label' => 'Dashboard', 'icon' => 'rect'],
            ['id' => 'masterdata', 'label' => 'Master Data', 'icon' => 'database'],
            ['id' => 'laporan', 'label' => 'Laporan', 'icon' => 'file-text'],
            ['id' => 'settings', 'label' => 'Settings', 'icon' => 'settings'],
        ]
    ],
    'gudang' => [
        'name' => 'Divisi Gudang',
        'menus' => [
            ['id' => 'dashboard', 'label' => 'Dashboard', 'icon' => 'rect'],
            ['id' => 'gudang', 'label' => 'Gudang', 'icon' => 'warehouse'],
            ['id' => 'laporan', 'label' => 'Laporan', 'icon' => 'file-text'],
        ]
    ],
    'produksi' => [
        'name' => 'Plan Produksi',
        'menus' => [
            ['id' => 'dashboard', 'label' => 'Dashboard', 'icon' => 'rect'],
            ['id' => 'produksi', 'label' => 'Produksi', 'icon' => 'factory'],
            ['id' => 'laporan', 'label' => 'Laporan', 'icon' => 'file-text'],
        ]
    ],
    'whf' => [
        'name' => 'Divisi WHF',
        'menus' => [
            ['id' => 'dashboard', 'label' => 'Dashboard', 'icon' => 'rect'],
            ['id' => 'whf', 'label' => 'WHF', 'icon' => 'box'],
            ['id' => 'laporan', 'label' => 'Laporan', 'icon' => 'file-text'],
        ]
    ]
];